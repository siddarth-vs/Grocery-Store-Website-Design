<?php
  $con=mysqli_connect("localhost","root","","grocerydb");
  if(!$con)
  {
    die("cannot connect to server");
  }    
?>